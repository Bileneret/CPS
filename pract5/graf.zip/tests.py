import unittest
import json
import os
import numpy as np
from unittest.mock import patch
from graf import generate_graph
from genetic import Seller, GeneticTSP
from main import load_graf, save_graf, load_genome, save_genome, get_user_input

class TestTSPProject(unittest.TestCase):
    def setUp(self):
        # Виконується перед кожним тестом для ініціалізації спільних даних
        self.n = 5  # Кількість вершин для тестів
        # Створюємо контрольований граф із ребрами для валідного генома [0, 1, 2, 3, 4, 0]
        self.graf = np.zeros((self.n, self.n), dtype=int)
        edges = [(0, 1, 5), (1, 2, 6), (2, 3, 7), (3, 4, 8), (4, 0, 9)]
        for i, j, w in edges:
            self.graf[i][j] = w
            self.graf[j][i] = w  # Симетричний граф
        self.mutation_rate = 0.1
        self.pop_size = 10
        self.generations = 5
        self.elite_size = max(1, self.pop_size // 10)
        self.sample_genome = [0, 1, 2, 3, 4, 0]  # Валідний геном для тестів
        self.tsp_instances = []  # Зберігаємо екземпляри GeneticTSP для закриття пулів

    def tearDown(self):
        # Виконується після кожного тесту для очищення
        # Закриваємо всі пули процесів
        for tsp in self.tsp_instances:
            tsp.pool.close()
            tsp.pool.join()
        # Видаляємо тестові файли
        for file in ["graf.json", "genome.json", "result.txt"]:
            if os.path.exists(file):
                os.remove(file)

    def test_generate_graph_dimensions(self):
        # Тест: Перевіряємо розміри згенерованого графа
        graf = generate_graph(self.n)
        self.assertEqual(graf.shape, (self.n, self.n), "Граф має бути квадратною матрицею NxN")
        self.assertTrue(np.all(np.diag(graf) == 0), "Діагональ графа має бути нульовою")

    def test_generate_graph_connectivity(self):
        # Тест: Перевіряємо, що граф є зв’язним
        graf = generate_graph(self.n)
        visited = set()
        stack = [0]
        visited.add(0)
        while stack:
            current = stack.pop()
            for j in range(self.n):
                if graf[current][j] != 0 and j not in visited:
                    visited.add(j)
                    stack.append(j)
        self.assertEqual(len(visited), self.n, "Граф має бути зв’язним")

    def test_generate_graph_symmetry(self):
        # Тест: Перевіряємо, що граф є симетричним (неорієнтованим)
        graf = generate_graph(self.n)
        self.assertTrue(np.all(graf == graf.T), "Граф має бути симетричним")

    def test_seller_initialize_genome(self):
        # Тест: Перевіряємо, що продавець ініціалізує валідний геном
        seller = Seller(self.graf, self.mutation_rate)
        genome = seller.genome
        self.assertEqual(len(genome), self.n + 1, "Геном має містити N+1 вершин")
        self.assertEqual(genome[0], 0, "Геном має починатися з вершини 0")
        self.assertEqual(genome[-1], 0, "Геном має закінчуватися вершиною 0")
        self.assertEqual(len(set(genome[:-1])), self.n, "Геном має відвідувати всі вершини один раз")

    def test_seller_evaluate_fitness(self):
        # Тест: Перевіряємо оцінку фітнесу продавця
        seller = Seller(self.graf, self.mutation_rate, genome=self.sample_genome)
        fitness = seller.evaluate_fitness()
        self.assertTrue(np.isfinite(fitness), "Фітнес має бути скінченним для валідного генома")
        expected_distance = sum(self.graf[i][j] for i, j in [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)])
        self.assertEqual(seller.distance, expected_distance, "Дистанція має відповідати сумі ваг ребер")
        # Враховуємо path_penalty, оскільки path = [0]
        path_penalty = 50 * abs(len(seller.path) - (self.n + 1))  # len(path)=1, n+1=6
        expected_points = 1000 - expected_distance - path_penalty
        self.assertEqual(seller.points, expected_points, "Фітнес має враховувати дистанцію та штраф за path")
        # Перевіряємо штраф за невалідний геном
        invalid_genome = [0, 1, 1, 0]  # Повтор вершини
        seller_invalid = Seller(self.graf, self.mutation_rate, genome=invalid_genome)
        fitness_invalid = seller_invalid.evaluate_fitness()
        self.assertEqual(fitness_invalid, -float('inf'), "Невалідний геном має мати фітнес -inf")

    def test_seller_move(self):
        # Тест: Перевіряємо рух продавця по геному
        seller = Seller(self.graf, self.mutation_rate, genome=self.sample_genome)
        initial_position = seller.position
        seller.move()
        self.assertNotEqual(seller.position, initial_position, "Продавець має змінити позицію")
        self.assertIn(seller.position, self.sample_genome, "Нова позиція має бути з генома")
        self.assertGreater(seller.steps, 0, "Кількість кроків має збільшитися")

    def test_genetic_tsp_initialization(self):
        # Тест: Перевіряємо ініціалізацію генетичного алгоритму
        tsp = GeneticTSP(self.graf, self.pop_size, self.generations, self.elite_size, self.mutation_rate)
        self.tsp_instances.append(tsp)  # Зберігаємо для закриття пулу
        self.assertEqual(len(tsp.population), self.pop_size, "Популяція має містити pop_size продавців")
        for seller in tsp.population:
            self.assertIsInstance(seller, Seller, "Кожен елемент популяції має бути Seller")
        self.assertTrue(os.path.exists("result.txt"), "Файл result.txt має бути створено")

    def test_save_and_load_graf(self):
        # Тест: Перевіряємо збереження та завантаження графа
        save_graf(self.graf)
        loaded_graf = load_graf()
        self.assertTrue(np.array_equal(self.graf, loaded_graf), "Завантажений граф має збігатися з оригіналом")
        self.assertTrue(os.path.exists("graf.json"), "Файл graf.json має бути створено")

    def test_save_and_load_genome(self):
        # Тест: Перевіряємо збереження та завантаження генома
        route = self.sample_genome
        distance = 50
        save_genome(route, distance)
        loaded_genome = load_genome()
        self.assertEqual(loaded_genome, distance, "Завантажений геном має відповідати distance")
        self.assertTrue(os.path.exists("genome.json"), "Файл genome.json має бути створено")
        # Тестуємо збереження з inf
        save_genome([], float('inf'))
        loaded_genome = load_genome()
        self.assertIsNone(loaded_genome, "При distance=inf best_route має бути None")

    @patch('builtins.input', side_effect=['5'])
    def test_get_user_input(self, mock_input):
        # Тест: Перевіряємо введення кількості вершин користувачем
        n = get_user_input()
        self.assertEqual(n, 5, "Введена кількість вершин має бути 5")

if __name__ == '__main__':
    unittest.main()