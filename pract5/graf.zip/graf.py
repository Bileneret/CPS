import random
import numpy as np

def generate_graph(n):
    graph = np.zeros((n, n), dtype=int)  # Ініціалізуємо матрицю нулями
    for i in range(n):
        for j in range(i + 1, n):
            if random.random() < 0.6:  # 100% ймовірність з'єднання
                weight = random.randint(2, 10)
                graph[i][j] = weight
                graph[j][i] = weight
    # Переконатися, що граф зв’язний
    visited = set()
    stack = [0]
    visited.add(0)
    while stack:
        current = stack.pop()
        for j in range(n):
            if graph[current][j] != 0 and j not in visited:
                visited.add(j)
                stack.append(j)
    for i in range(n):
        if i not in visited:
            j = random.choice(list(visited))
            weight = random.randint(2, 10)
            graph[i][j] = weight
            graph[j][i] = weight
            visited.add(i)
    return graph