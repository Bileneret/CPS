import random
import numpy as np
import time
import threading
import sys
from multiprocessing import Pool, cpu_count
from python_tsp.exact import solve_tsp_dynamic_programming
from collections import deque

def evaluate_seller(seller):
    seller.evaluate_fitness()
    return seller

class Seller:
    def __init__(self, graf, mutation_rate, genome=None):
        self.graf = graf
        self.n = len(graf)
        self.mutation_rate = mutation_rate
        self.genome = self._initialize_genome() if genome is None else genome[:]
        self.gi = 0
        self.position = 0  # Поточна вершина
        self.path = [0]  # Пройдений шлях
        self.points = 1000  # Початкові бали
        self.best_points = 1000
        self.alive = True
        self.found = {0}  # Відвідані вершини
        self.steps = 0
        self.max_steps = 2 * self.n
        self.transition = None  # Для анімації
        self.distance = 0  # Фактична дистанція
        self.best_fitness = float('-inf')

    def _initialize_genome(self):
        max_attempts = 2000  # Збільшуємо кількість спроб
        vertices = list(range(1, self.n))
        for _ in range(max_attempts):
            random.shuffle(vertices)
            genome = [0] + vertices + [0]
            if self._is_valid_genome(genome):
                return genome
        # Спроба побудувати валідний геном через BFS
        return self._construct_valid_genome()

    def _is_valid_genome(self, genome):
        if len(genome) != self.n + 1 or genome[0] != 0 or genome[-1] != 0:
            return False
        for i in range(len(genome) - 1):
            if self.graf[genome[i]][genome[i + 1]] == 0:
                return False
        return len(set(genome[:-1])) == self.n  # Усі вершини унікальні, крім останнього 0

    def _construct_valid_genome(self):
        # Використовуємо BFS для побудови зв’язного маршруту
        vertices = set(range(1, self.n))
        genome = [0]
        current = 0
        visited = {0}
        while vertices:
            neighbors = [v for v in range(self.n) if self.graf[current][v] != 0 and v not in visited]
            if not neighbors:
                # Якщо немає сусідів, повертаємо частково валідний
                remaining = list(vertices)
                random.shuffle(remaining)
                return [0] + remaining + [0]
            next_v = random.choice(neighbors)
            genome.append(next_v)
            visited.add(next_v)
            vertices.discard(next_v)
            current = next_v
        if self.graf[current][0] != 0:
            genome.append(0)
            return genome
        # Якщо не можемо повернутися до 0, повертаємо частково валідний
        remaining = list(range(1, self.n))
        random.shuffle(remaining)
        return [0] + remaining + [0]

    def evaluate_fitness(self):
        self.distance = 0
        valid = True
        seen = {0}
        repeat_penalty = 0
        # Послаблюємо перевірку path для початкових поколінь
        if self.genome[-1] != 0 or len(self.genome) != self.n + 1:
            valid = False
        for i in range(len(self.genome) - 1):
            curr, next_v = self.genome[i], self.genome[i + 1]
            if self.graf[curr][next_v] == 0:
                valid = False
                break
            self.distance += self.graf[curr][next_v]
            if next_v in seen and next_v != 0:
                repeat_penalty += 50
            seen.add(next_v)
        missing_penalty = 100 * (self.n - 1 - (len(seen) - 1))
        path_penalty = 50 * abs(len(self.path) - (self.n + 1))  # Штраф за невідповідність path
        self.points = (1000 - self.distance - repeat_penalty - missing_penalty - path_penalty) if valid else -float('inf')
        self.best_points = max(self.best_points, self.points)
        self.best_fitness = max(self.best_fitness, self.points / max(1, self.steps))
        return self.points

    def move(self):
        if not self.alive or self.gi >= len(self.genome) - 1 or self.steps >= self.max_steps:
            self.alive = False
            return
        
        next_vertex = self.genome[self.gi + 1]
        if self.graf[self.position][next_vertex] == 0:
            available_vertices = [v for v in range(self.n) if self.graf[self.position][v] != 0 and v not in self.found]
            if available_vertices:
                next_vertex = random.choice(available_vertices)
                self.genome[self.gi + 1] = next_vertex
            else:
                self.points = -float('inf')
                self.alive = False
                return
        
        self.distance += self.graf[self.position][next_vertex]
        self.points = 1000 - self.distance
        self.transition = (self.position, next_vertex, 0.0)
        self.position = next_vertex
        self.path.append(next_vertex)
        self.found.add(next_vertex)
        self.gi += 1
        self.steps += 1
        
        # Якщо досягли передостанньої вершини, додаємо повернення до 0
        if self.gi == len(self.genome) - 1:
            if self.graf[self.position][0] != 0:
                self.distance += self.graf[self.position][0]
                self.path.append(0)
                self.found.add(0)
                self.points = 1000 - self.distance
            else:
                self.points = -float('inf')
            self.alive = False

    def update_transition(self, progress):
        if self.transition:
            self.transition = (self.transition[0], self.position, progress)
            if progress >= 1.0:
                self.transition = None

    def clone(self, mutate=False, parent2=None):
        new_genome = self.genome[:]
        if mutate and random.random() < 0.3:
            if random.random() < 0.5 and parent2:
                start, end = sorted(random.sample(range(1, len(new_genome) - 1), 2))
                child = [None] * len(new_genome)
                child[start:end] = new_genome[start:end]
                # Забезпечуємо унікальність вершин у remaining
                used = set(child[start:end]) - {None}
                remaining = []
                for v in parent2.genome[1:-1]:
                    if v not in used:
                        remaining.append(v)
                        used.add(v)
                if len(remaining) != len(new_genome) - len(child[start:end]) - 2:
                    # Якщо remaining некоректний, використовуємо мутацію обміну
                    idx1, idx2 = random.sample(range(1, len(new_genome) - 1), 2)
                    new_genome[idx1], new_genome[idx2] = new_genome[idx2], new_genome[idx1]
                else:
                    idx = 0
                    for i in range(1, len(new_genome) - 1):
                        if i < start or i >= end:
                            child[i] = remaining[idx]
                            idx += 1
                    child[0] = child[-1] = 0
                    new_genome = child
            else:
                idx1, idx2 = random.sample(range(1, len(new_genome) - 1), 2)
                new_genome[idx1], new_genome[idx2] = new_genome[idx2], new_genome[idx1]
        # Перевірка валідності нового генома
        if self._is_valid_genome(new_genome):
            return Seller(self.graf, self.mutation_rate, genome=new_genome)
        return Seller(self.graf, self.mutation_rate, genome=self.genome[:])

class GeneticTSP:
    def __init__(self, graf, pop_size, generations, elite_size, mutation_rate, loaded_genome=None):
        self.graf = graf
        self.pop_size = pop_size
        self.generations = generations
        self.elite_size = max(1, pop_size // 10)
        self.mutation_rate = mutation_rate
        self.canvas = None
        self.delay = 0.000005
        self.distance_matrix = np.where(self.graf == 0, 1e9, self.graf)
        self.optimal_path, self.optimal_distance = self._get_optimal_solution()
        with open("result.txt", "w") as f:
            f.write(f"Optimal Path: {self.optimal_path}, Distance: {self.optimal_distance:.2f}\n")
        self.population = self._initialize_population(loaded_genome)
        self.best_by_points = None
        self.best_by_distance = None
        self.pool = Pool(cpu_count())

    def _get_optimal_solution(self):
        try:
            path, distance = solve_tsp_dynamic_programming(self.distance_matrix)
            start_idx = path.index(0)
            normalized_path = path[start_idx:] + path[:start_idx] + [0]
            return normalized_path, distance
        except Exception as e:
            print(f"Помилка при обчисленні оптимального маршруту: {e}")
            return [], float('inf')

    def _compare_paths(self, path1, path2):
        if len(path1) != len(path2):
            return False
        n = len(path1)
        for i in range(n):
            shifted = path2[i:] + path2[:i]
            if path1 == shifted:
                return True
        reversed_path2 = path2[::-1]
        for i in range(n):
            shifted = reversed_path2[i:] + reversed_path2[:i]
            if path1 == shifted:
                return True
        return False

    def set_canvas(self, canvas):
        self.canvas = canvas

    def _initialize_population(self, loaded_genome):
        population = []
        n = len(self.graf)
        if loaded_genome and self._is_valid_genome(loaded_genome):
            population.append(Seller(self.graf, self.mutation_rate, genome=loaded_genome))
        while len(population) < self.pop_size:
            population.append(Seller(self.graf, self.mutation_rate))
        return population

    def train(self):
        def loop():
            for gen in range(1, self.generations + 1):
                print(f"\n=== Покоління {gen} ===")
                for step in range(len(self.graf) + 1):
                    for seller in self.population:
                        if seller.alive:
                            seller.move()
                    if self.canvas:
                        self.canvas.draw_sellers()
                    time.sleep(self.delay)
                
                self.population = self.pool.map(evaluate_seller, self.population)
                
                valid_sellers = [s for s in self.population if len(s.found) == len(self.graf) and s.path[-1] == 0 and len(s.path) == len(self.graf) + 1]
                print(f"Кількість валідних продавців: {len(valid_sellers)}")
                if valid_sellers:
                    by_points = max(valid_sellers, key=lambda s: s.points)
                    by_distance = min(valid_sellers, key=lambda s: s.distance)
                else:
                    by_points = sorted(self.population, key=lambda s: s.points, reverse=True)[0]
                    by_distance = sorted(self.population, key=lambda s: s.distance if s.distance < 1e9 else float('inf'))[0]
                
                if not self.best_by_points or by_points.points > self.best_by_points.points:
                    self.best_by_points = by_points
                if valid_sellers and (not self.best_by_distance or (by_distance.distance < 1e9 and
                        by_distance.distance < self.best_by_distance.distance)):
                    self.best_by_distance = by_distance
                
                print(f"Найкращий продавець: points={self.best_by_points.points:.2f}, "
                      f"\ndistance={self.best_by_distance.distance if self.best_by_distance and self.best_by_distance.distance < 1e9 else 'inf'}, "
                      f"\npath={self.best_by_distance.path if self.best_by_distance else 'немає'}")
                
                if self.best_by_distance and self.best_by_distance.distance < 1e9:
                    if self._compare_paths(self.best_by_distance.path, self.optimal_path):
                        print(f"Знайдено оптимальний маршрут: {self.best_by_distance.path}, distance: {self.best_by_distance.distance}")
                        with open("result.txt", "a") as f:
                            f.write("Find = Lib\n")
                        self.pool.close()
                        self.pool.join()
                        break
                
                new_pop = []
                elite = sorted(self.population, key=lambda s: s.points, reverse=True)[:self.elite_size]
                new_pop.extend(elite)
                
                for _ in range(self.pop_size - self.elite_size):
                    parent1 = random.choice(elite)
                    parent2 = random.choice(elite)
                    new_pop.append(parent1.clone(mutate=True, parent2=parent2))
                
                self.population = new_pop
                
                if self.canvas:
                    self.canvas.draw_sellers()
                    if self.best_by_distance:
                        self.canvas.draw_route(self.best_by_distance.path)
                time.sleep(0.5)
            
            print("\nТренування завершено.")
            self.pool.close()
            self.pool.join()
        
        threading.Thread(target=loop, daemon=True).start()

    def get_best(self):
        if self.best_by_distance and self.best_by_distance.distance < 1e9:
            return self.best_by_distance.path, self.best_by_distance.distance
        return [], float('inf')

    def _is_valid_genome(self, genome):
        if len(genome) != self.n + 1 or genome[0] != 0 or genome[-1] != 0:
            return False
        for i in range(len(genome) - 1):
            if self.graf[genome[i]][genome[i + 1]] == 0:
                return False
        return len(set(genome[:-1])) == self.n