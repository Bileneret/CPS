import tkinter as tk
import numpy as np

class GraphWindow:
    def __init__(self, graf, trainer, margin=20):
        self.graf = graf
        self.trainer = trainer
        self.n = len(graf)
        self.margin = margin
        self.positions = self._generate_positions()
        self.cell_size = 1
        self.offset_x = margin
        self.offset_y = margin
        
        self.root = tk.Tk()
        self.root.title("Задача комівояжера")
        self.root.geometry("800x800")  # Вікно 800x800 за замовчуванням
        self.root.attributes("-topmost", True)  # Поверх інших вікон
        self.canvas = tk.Canvas(self.root, bg="white", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.canvas.bind("<Configure>", self._on_resize)
        self.root.after(200, lambda: self.trainer.train())

    def _generate_positions(self):
        positions = []
        radius = 250  # Радіус для розташування вершин
        center_x, center_y = 400, 400  # Центр для базового розміру 800x800
        for i in range(self.n):
            angle = 2 * np.pi * i / self.n
            x = center_x + radius * np.cos(angle)
            y = center_y + radius * np.sin(angle)
            positions.append((x, y))
        return positions

    def _on_resize(self, event):
        self.canvas.delete("all")
        # Обчислюємо розмір комірки для масштабування
        w = event.width - 2 * self.margin
        h = event.height - 2 * self.margin
        self.cell_size = min(w / 800, h / 800) * 250  # Масштабуємо відносно 800x800
        self.offset_x = event.width / 2
        self.offset_y = event.height / 2
        self._draw_static()
        self.draw_sellers()

    def _draw_static(self):
        r = 15 * self.cell_size / 250  # Масштабуємо розмір вершин
        for i, (x, y) in enumerate(self.positions):
            x_scaled = self.offset_x + (x - 400) * self.cell_size / 250
            y_scaled = self.offset_y + (y - 400) * self.cell_size / 250
            self.canvas.create_oval(x_scaled - r, y_scaled - r, x_scaled + r, y_scaled + r,
                                  fill="grey", outline="black", tags="static")
            self.canvas.create_text(x_scaled, y_scaled - 20 * self.cell_size / 250,
                                  text=str(i + 1), tags="static")
        
        for i in range(self.n):
            for j in range(i, self.n):
                if self.graf[i][j] != 0:
                    x1, y1 = self.positions[i]
                    x2, y2 = self.positions[j]
                    x1_scaled = self.offset_x + (x1 - 400) * self.cell_size / 250
                    y1_scaled = self.offset_y + (y1 - 400) * self.cell_size / 250
                    x2_scaled = self.offset_x + (x2 - 400) * self.cell_size / 250
                    y2_scaled = self.offset_y + (y2 - 400) * self.cell_size / 250
                    self.canvas.create_line(x1_scaled, y1_scaled, x2_scaled, y2_scaled,
                                          fill="black", width=4 * self.cell_size / 250, tags="static")
                    mid_x = (x1_scaled + x2_scaled) / 2
                    mid_y = (y1_scaled + y2_scaled) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(self.graf[i][j]),
                                          fill="blue", tags="static")

    def draw_sellers(self):
        self.canvas.delete("seller")
        r = 8 * self.cell_size / 250  # Масштабуємо розмір продавців
        for seller in self.trainer.population:
            if not seller.alive:
                continue
            if seller.transition:
                from_vertex, to_vertex, progress = seller.transition
                x1, y1 = self.positions[from_vertex]
                x2, y2 = self.positions[to_vertex]
                x = x1 + (x2 - x1) * progress
                y = y1 + (y2 - y1) * progress
            else:
                x, y = self.positions[seller.position]
            x_scaled = self.offset_x + (x - 400) * self.cell_size / 250
            y_scaled = self.offset_y + (y - 400) * self.cell_size / 250
            self.canvas.create_rectangle(x_scaled - r, y_scaled - r, x_scaled + r, y_scaled + r,
                                       fill="green", outline="black", tags="seller")

    def draw_route(self, route):
        self.canvas.delete("route")
        if not route:
            return
        for i in range(len(route) - 1):
            x1, y1 = self.positions[route[i]]
            x2, y2 = self.positions[route[i + 1]]
            x1_scaled = self.offset_x + (x1 - 400) * self.cell_size / 250
            y1_scaled = self.offset_y + (y1 - 400) * self.cell_size / 250
            x2_scaled = self.offset_x + (x2 - 400) * self.cell_size / 250
            y2_scaled = self.offset_y + (y2 - 400) * self.cell_size / 250
            self.canvas.create_line(x1_scaled, y1_scaled, x2_scaled, y2_scaled,
                                  fill="red", width=2 * self.cell_size / 250, tags="route")
        if len(route) > 1 and route[0] == route[-1] and len(set(route)) == self.n:
            x1, y1 = self.positions[route[-1]]
            x2, y2 = self.positions[route[0]]
            x1_scaled = self.offset_x + (x1 - 400) * self.cell_size / 250
            y1_scaled = self.offset_y + (y1 - 400) * self.cell_size / 250
            x2_scaled = self.offset_x + (x2 - 400) * self.cell_size / 250
            y2_scaled = self.offset_y + (y2 - 400) * self.cell_size / 250
            self.canvas.create_line(x1_scaled, y1_scaled, x2_scaled, y2_scaled,
                                  fill="red", width=2 * self.cell_size / 250, tags="route")

    def run(self):
        self.root.mainloop()