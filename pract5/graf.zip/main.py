#Travelling Salesman Problem
import json
import numpy as np
from graf import generate_graph
from graph import GraphWindow
from genetic import GeneticTSP

def load_graf():
    try:
        with open("graf.json", "r") as f:
            data = json.load(f)
            return np.array(data["graf"])
    except FileNotFoundError:
        print("Файл graf.json не знайдено.")
        return None

def save_graf(graf):
    with open("graf.json", "w") as f:
        json.dump({"graf": graf.tolist()}, f)

# def load_genome():
#     try:
#         with open("genome.json", "r") as f:
#             data = json.load(f)
#             return data.get("best_route", [])
#     except FileNotFoundError:
#         print("Файл genome.json не знайдено.")
#         return []

# def save_genome(route, distance):
#     with open("genome.json", "w") as f:
#         json.dump({"best_route": None if distance == float('inf') else int(distance)}, f)

def get_user_input():
    while True:
        try:
            n = int(input("Введіть кількість клієнтів (вершин): "))
            if n > 0:
                return n
        except ValueError:
            print("Некоректне введення. Спробуйте знову.")

def main():
    print("Задача комівояжера: пошук найкоротшого маршруту.")
    choice_graf = input("Завантажити існуючий граф? (+ / -): ").strip()
    if choice_graf == "+":
        graf = load_graf()
        if graf is None:
            print("Генерується новий граф.")
            n = get_user_input()
            graf = generate_graph(n)
        else:
            n = len(graf)
            print(f"Граф завантажено з graf.json: {n} вершин.")
    else:
        n = get_user_input()
        graf = generate_graph(n)
    
    save_graf(graf)
    
    while True:
        try:
            pop_size = int(input("Введіть кількість продавців (розмір популяції): "))
            generations = int(input("Введіть кількість поколінь: "))
            if pop_size > 0 and generations > 0:
                break
        except ValueError:
            print("Некоректне введення. Спробуйте знову.")
    
    # choice_genome = input("Завантажити існуючий геном продавця? (+ / -): ").strip()
    # loaded_genome = load_genome() if choice_genome == "+" else []
    # if loaded_genome and choice_genome == "+":
    #     print("Геном завантажено з genome.json.")
    # elif choice_genome == "+":
    #     print("Починається з нового генома.")
    
    elite_size = max(1, pop_size // 10)  # 10% елітних особин
    mutation_rate = 0.1
    
    # tsp = GeneticTSP(graf, pop_size, generations, elite_size, mutation_rate, loaded_genome)
    tsp = GeneticTSP(graf, pop_size, generations, elite_size, mutation_rate)
    app = GraphWindow(graf, tsp)
    tsp.set_canvas(app)
    app.run()
    
    best_route, best_distance = tsp.get_best()
    print(f"Найкращий маршрут: {best_route}")
    print(f"Найкраща відстань: {best_distance if best_distance != float('inf') else 'не знайдено'}")


if __name__ == "__main__":
    main()