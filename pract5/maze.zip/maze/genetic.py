import random
import time
import threading
from multiprocessing import Pool, cpu_count
from math import fabs

DIRS = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}

def move_seller(seller):
    if seller.alive:
        seller.move()
    return seller

class Seller:
    def __init__(self, start, maze, customers, genome=None):
        self.start = start
        self.position = start
        self.path = [start]
        self.points = 0
        self.best_points = 0
        self.steps = 0
        self.best_fitness = float("-inf")
        self.maze = maze
        self.customers = set(tuple(c) if isinstance(c, list) else c for c in customers)
        self.found = set()
        self.alive = True
        self.genome = genome[:] if genome else []
        self.gi = 0
        self.steps_since_last_customer = 0
        self.visit_count = {}
        self.max_genome_length = 3 * len(maze) * len(maze[0])
        self.last_directions = []

    def manhattan_distance(self, pos1, pos2):
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def move(self):
        if not self.alive or self.gi >= self.max_genome_length:
            self.alive = False
            return

        if self.gi < len(self.genome):
            d = self.genome[self.gi]
        else:
            d = random.choice(list(DIRS.keys()))
            self.genome.append(d)
        self.gi += 1

        dx, dy = DIRS[d]
        nx, ny = self.position[0] + dx, self.position[1] + dy

        if not (0 <= nx < len(self.maze) and 0 <= ny < len(self.maze[0])) or self.maze[nx][ny] == 1:
            self.points -= 2
            if self.points <= 0:
                self.alive = False
            return

        self.steps += 1
        self.steps_since_last_customer += 1
        self.points += 1
        self.points -= 0.01

        next_pos = (nx, ny)

        if next_pos in self.path:
            self.points -= 1

        self.visit_count[next_pos] = self.visit_count.get(next_pos, 0) + 1
        if self.visit_count[next_pos] > 3:
            self.points -= 3

        self.last_directions.append(d)
        if len(self.last_directions) > 3:
            self.last_directions.pop(0)
        if len(self.last_directions) == 3 and all(dir == self.last_directions[0] for dir in self.last_directions):
            self.points += 2

        if len(self.found) == len(self.customers):
            old_distance = self.manhattan_distance(self.position, self.start)
            new_distance = self.manhattan_distance(next_pos, self.start)
            if new_distance < old_distance:
                self.points += 1
            elif new_distance > old_distance:
                self.points -= 1

        self.position = next_pos
        self.path.append(next_pos)

        if next_pos in self.customers:
            if next_pos not in self.found:
                count = len(self.found) + 1
                self.points += 10 * count
                self.points += 2
                self.points += 5
                self.points += 5 / max(1, self.steps_since_last_customer)
                self.found.add(next_pos)
                self.steps_since_last_customer = 0
            elif len(self.found) < len(self.customers):
                self.visit_count[next_pos] = self.visit_count.get(next_pos, 0) + 1
                if self.visit_count[next_pos] > 2:
                    self.points -= 60
                else:
                    self.points -= 50

        if self.steps_since_last_customer >= 10:
            self.points -= 5
            self.steps_since_last_customer = 0

        if self.steps_since_last_customer >= 5 and self.steps_since_last_customer < 10:
            self.points -= 4

        if len(self.path) >= 6 and len(set(self.path[-5:])) == 5:
            self.points += 1

        if self.position == self.start and len(self.found) == len(self.customers):
            self.points += 50
            self.points += 100 / max(1, self.steps)
            self.alive = False

        self.best_points = max(self.best_points, self.points)
        if self.steps > 0:
            self.best_fitness = max(self.best_fitness, self.points / self.steps)

        if self.points <= 0:
            self.alive = False

    def fitness(self):
        return self.points / self.steps if self.steps > 0 else float("-inf")

    def clone(self, mutate=False):
        new_genome = self.genome[:]
        if mutate and new_genome and random.random() < 0.5:
            for _ in range(random.randint(1, 3)):
                idx = random.randrange(len(new_genome))
                new_genome[idx] = random.choice(list(DIRS.keys()))
        return Seller(self.start, self.maze, self.customers, genome=new_genome)

class GeneticTrainer:
    def __init__(self, maze, customers, pop_size, generations, loaded_genome):
        self.maze = maze
        self.customers = customers
        self.pop_size = pop_size
        self.generations = generations
        self.canvas = None
        self.delay = 0.03
        self.entrance = self._find_entrance()
        self.population = self._initialize_population(loaded_genome)
        self.best_by_steps = None
        self.best_by_points = None
        self.best_by_fitness = None
        self.pool = Pool(cpu_count())

    def set_canvas(self, canvas):
        self.canvas = canvas

    def _find_entrance(self):
        n, m = len(self.maze), len(self.maze[0])
        for i in range(n):
            for j in range(m):
                if (i in (0, n-1) or j in (0, m-1)) and self.maze[i][j] == 0:
                    return (i, j)
        return (1, 1)

    def _initialize_population(self, loaded_genome):
        population = []
        if loaded_genome:
            population.append(Seller(self.entrance, self.maze, self.customers, genome=loaded_genome))
        while len(population) < self.pop_size:
            population.append(Seller(self.entrance, self.maze, self.customers))
        return population

    def train(self, ui):
        def loop():
            for gen in range(1, self.generations + 1):
                print(f"\n=== Покоління {gen} ===")
                while any(s.alive for s in self.population):
                    self.population = list(self.pool.map(move_seller, self.population))
                    if self.canvas:
                        ui._draw_sellers()
                    time.sleep(self.delay)

                by_steps = sorted(self.population, key=lambda s: s.steps, reverse=True)[0]
                by_points = sorted(self.population, key=lambda s: s.best_points, reverse=True)[0]
                by_fit = sorted(self.population, key=lambda s: s.best_fitness, reverse=True)[0]

                if not self.best_by_steps or by_steps.steps > self.best_by_steps.steps:
                    self.best_by_steps = by_steps
                if not self.best_by_points or by_points.best_points > self.best_by_points.best_points:
                    self.best_by_points = by_points
                if not self.best_by_fitness or by_fit.best_fitness > self.best_by_fitness.best_fitness:
                    self.best_by_fitness = by_fit

                print("Батьки цього покоління:")
                print(f" - За кроками:    steps={by_steps.steps}, points={by_steps.best_points:.1f}, fitness={by_steps.best_fitness:.3f}, found_customers={len(by_steps.found)}")
                print(f" - За балами:     steps={by_points.steps}, points={by_points.best_points:.1f}, fitness={by_points.best_fitness:.3f}, found_customers={len(by_points.found)}")
                print(f" - За коефіцієнтом: steps={by_fit.steps}, points={by_fit.best_points:.1f}, fitness={by_fit.best_fitness:.3f}, found_customers={len(by_fit.found)}")

                new_pop = []
                quarter = max(1, self.pop_size // 4)
                for _ in range(quarter):
                    new_pop.append(by_steps.clone(mutate=True))
                for _ in range(quarter):
                    new_pop.append(by_points.clone(mutate=True))
                for _ in range(quarter):
                    new_pop.append(by_fit.clone(mutate=True))
                for _ in range(self.pop_size - 3 * quarter):
                    new_pop.append(Seller(self.entrance, self.maze, self.customers))
                self.population = new_pop

                if self.canvas:
                    ui._draw_sellers()
                time.sleep(0.5)

            print("\nТренування завершено.")
            self.pool.close()
            self.pool.join()
        threading.Thread(target=loop, daemon=True).start()

    def get_best_sellers(self):
        return self.best_by_steps, self.best_by_points, self.best_by_fitness