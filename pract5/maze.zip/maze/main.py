import json
from graph import GraphWindow
from maze import generate_maze, place_customers
from genetic import GeneticTrainer

SAVE_FILE = "best_seller_genes.json"
MAZE_FILE = "maze.json"

def get_user_input():
    while True:
        try:
            size = input("Введіть розмір лабіринту у форматі NxM (наприклад 20x30): ").lower()
            n, m = map(int, size.replace('*', 'x').split('x'))
            if 1 <= n <= 100 and 1 <= m <= 100:
                return n, m
        except:
            pass
        print("Некоректне введення. Спробуйте знову.")

def get_customer_count():
    while True:
        try:
            count = int(input("Введіть кількість клієнтів: "))
            if count > 0:
                return count
        except:
            pass
        print("Некоректне введення. Спробуйте знову.")

def load_genes():
    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
            return data.get("best_by_fitness", [])
    except FileNotFoundError:
        return []

def save_genes(best_by_steps, best_by_points, best_by_fitness):
    with open(SAVE_FILE, "w") as f:
        json.dump({
            "best_by_steps": best_by_steps or [],
            "best_by_points": best_by_points or [],
            "best_by_fitness": best_by_fitness or []
        }, f)

def load_maze():
    try:
        with open(MAZE_FILE, "r") as f:
            data = json.load(f)
            maze = data.get("maze", [])
            customers = [tuple(customer) for customer in data.get("customers", [])]
            return maze, customers
    except FileNotFoundError:
        return None, None

def save_maze(maze, customers):
    with open(MAZE_FILE, "w") as f:
        json.dump({"maze": maze, "customers": customers}, f)

def main():
    choice_maze = input("Завантажити готовий лабіринт? (+ / -): ").strip()
    if choice_maze == "+":
        maze, customers = load_maze()
        if maze and customers:
            print("Лабіринт успішно завантажено з файлу.")
        else:
            print("Файл лабіринту не знайдено, генерується новий.")
            n, m = get_user_input()
            count = get_customer_count()
            maze = generate_maze(n, m)
            customers = place_customers(maze, count)
    else:
        n, m = get_user_input()
        count = get_customer_count()
        maze = generate_maze(n, m)
        customers = place_customers(maze, count)

    print(f"Кількість клієнтів у лабіринті: {len(customers)}")

    while True:
        try:
            pop_size = int(input("Введіть кількість популяції (продавців): "))
            generations = int(input("Введіть кількість ітерацій (поколінь): "))
            if pop_size > 0 and generations > 0:
                break
        except:
            pass
        print("Некоректне введення. Спробуйте знову.")

    choice_genes = input("Завантажити найкращого продавця? (+ / -): ").strip()
    loaded_genome = load_genes() if choice_genes == "+" else []

    trainer = GeneticTrainer(maze, customers, pop_size, generations, loaded_genome)
    app = GraphWindow(maze, customers, trainer)
    trainer.set_canvas(app)
    app.run()

    best_by_steps, best_by_points, best_by_fitness = trainer.get_best_sellers()
    if best_by_steps or best_by_points or best_by_fitness:
        save_genes(
            best_by_steps.genome if best_by_steps else [],
            best_by_points.genome if best_by_points else [],
            best_by_fitness.genome if best_by_fitness else []
        )
        print(f"Збережено геноми трьох найкращих продавців у {SAVE_FILE}")

    save_maze(maze, customers)
    print(f"Збережено лабіринт та клієнтів у {MAZE_FILE}")

if __name__ == "__main__":
    main()