import tkinter as tk

class GraphWindow:
    def __init__(self, maze, customers, trainer, margin=10):
        self.maze = maze
        self.customers = customers
        self.trainer = trainer
        self.rows = len(maze)
        self.cols = len(maze[0])
        self.margin = margin

        self.cell_size = 1
        self.offset_x = margin
        self.offset_y = margin

        self.root = tk.Tk()
        self.root.title("Maze Trainer")
        self.canvas = tk.Canvas(self.root, bg="grey", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.canvas.bind("<Configure>", self._on_resize)
        self.root.after(200, lambda: self.trainer.train(self))

    def _on_resize(self, event):
        self.canvas.delete("static")
        w = event.width - 2*self.margin
        h = event.height - 2*self.margin
        self.cell_size = min(w//self.cols, h//self.rows)
        self.offset_x = (event.width - self.cell_size*self.cols)//2
        self.offset_y = (event.height - self.cell_size*self.rows)//2
        self._draw_static()
        self._draw_sellers()

    def _draw_static(self):
        cs = self.cell_size
        for i in range(self.rows):
            for j in range(self.cols):
                x1 = self.offset_x + j*cs
                y1 = self.offset_y + i*cs
                x2, y2 = x1+cs, y1+cs
                color = "black" if self.maze[i][j]==1 else "white"
                self.canvas.create_rectangle(x1,y1,x2,y2,
                                             fill=color, outline="",
                                             tags="static")
        for i,j in self.customers:
            x1 = self.offset_x + j*cs
            y1 = self.offset_y + i*cs
            x2, y2 = x1+cs, y1+cs
            self.canvas.create_rectangle(x1,y1,x2,y2,
                                         fill="yellow", outline="",
                                         tags="static")

    def _draw_sellers(self):
        self.canvas.delete("seller")
        cs = self.cell_size
        for seller in self.trainer.population:
            if not seller.alive: continue
            i,j = seller.position
            x1 = self.offset_x + j*cs
            y1 = self.offset_y + i*cs
            x2, y2 = x1+cs, y1+cs
            self.canvas.create_rectangle(x1,y1,x2,y2,
                                         fill="green", outline="",
                                         tags="seller")

    def run(self):
        self.root.mainloop()
